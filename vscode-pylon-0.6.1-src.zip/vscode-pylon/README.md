# Pylon Language Support for VS Code

Syntax highlighting, live diagnostics, snippets, build commands, and a custom
file icon for the **Pylon** programming language — a Java-syntax dialect of
Python that compiles to Cython and runs as native code.

<p align="center">
  <img src="icons/pylon-logo.png" alt="Pylon logo" width="256">
</p>

## Features

### Syntax highlighting

A full TextMate grammar (`syntaxes/pylon.tmLanguage.json`) covering:

- **Types** — `int`, `float`, `boolean`, `string`, `bytes`, `bytearray`, `list`,
  `tuple`, `dict`, `set`, `frozenset`, `memoryview`, `range`, `NoneType`,
  `object`, `complex`, `bool`, `str`
- **Keywords** — `def`, `class`, `const`, `if`/`elif`/`else`, `while`, `for`,
  `return`, `break`, `continue`, `pass`, `import`, `from`, `as`, `try`,
  `except`, `finally`, `with`, `raise`, `assert`, `del`, `global`, `nonlocal`,
  `lambda`, `yield`
- **Function and class definitions** — return type, name, parameters, base
  classes all get distinct scopes (entity.name.function,
  entity.name.class, variable.parameter, support.type)
- **f-strings** — the `f"..."` prefix, the body, the `{replacement}` regions,
  the `:format-spec`, and escape sequences are each their own scope so themes
  can color them distinctly
- **String variants** — `f`, `r`, `b`, `u` prefixes; single, double, and
  triple-quoted; raw and bytes variants
- **Numbers** — hex (`0x...`), octal (`0o...`), binary (`0b...`), float,
  complex (`...j`), with underscore separators
- **Operators** — augmented (`+=`, `//=`, `**=`, …), arithmetic, comparison,
  assignment, logical word-ops (`and`, `or`, `not`, `in`, `is`)
- **Comments** — `#` line comments
- **Built-in functions** — `print`, `len`, `range`, `open`, `isinstance`,
  etc. are scoped as `support.function.builtin` when followed by `(`

### Live diagnostics (Problems panel)

A TypeScript port of `pylonc.py`'s tokenizer and the error-detection parts of
its parser runs on every keystroke (debounced, default 300 ms). It reports:

- **Lexer errors** — unexpected characters, unterminated string literals,
  bad string prefixes
- **Missing semicolons** — the most common Pylon mistake. pylonc itself is
  silently greedy here (it would swallow the next statement into the current
  one's initializer, producing bogus Cython); our checker catches it live
- **Missing closing braces** — unclosed `{ ... }` blocks
- **Keywords used as names** — `int def = 5;` → "Cannot use keyword 'def' as
  variable name"
- **Unknown type names** — `const Foo x = 1;` → "Unknown type 'Foo' in const
  declaration"
- **Missing parens in function defs** — `def int f int n {` → "Expected '('
  after function name"
- **Structural mismatches** — `}` where `;` was expected, etc.

The checker is intentionally permissive about full expression grammar — that
validation is delegated to the real `pylonc` at compile time, which is the
source of truth. Our job is to surface the structural mistakes that cause
the most confusing compile errors, as fast as possible.

You can disable live diagnostics with `pylon.enableDiagnostics: false`, and
tune the debounce with `pylon.debounceMs`.

### Snippets

Type the prefix and press Tab:

| Prefix | Expands to |
| --- | --- |
| `def` | `def <Type> <name>(<Type param>) { ... return <0>; }` |
| `defn` | `def NoneType <name>(<param>) { ... }` |
| `defstr` | `def string <name>(<int param>) { return f"...{$2}"; }` |
| `class` | class with `__init__` and a field |
| `for` / `forin` | `for i in range(n) { ... }` / `for item in iterable { ... }` |
| `while` | `while cond { ... }` |
| `ifelse` / `ifelif` | if-else / if-elif-else chain |
| `try` | try-except-finally with `as e` binding |
| `with` | `with open("file", "r") as fh { ... }` |
| `int` / `float` / `string` / `boolean` / `list` / `dict` | typed variable declarations |
| `const` | `const <Type> <NAME> = <value>;` |
| `print` | `print(f"...{$2}");` |
| `import` / `from` | `import module;` / `from module import name;` |

### Build commands

Four commands in the Command Palette (`Ctrl/Cmd+Shift+P`), under the **Pylon**
category. They shell out to the Pylon compiler (`pylonc.py`):

| Command | What it does |
| --- | --- |
| **Pylon: Compile current file** | `pylonc --no-cache --no-run <file>` — build the `.so`, don't run |
| **Pylon: Compile to standalone executable (--embed)** | same with `--embed` — build a standalone binary |
| **Pylon: Compile and run current file** | build + run the program; output goes to the Pylon output channel |
| **Pylon: Clean build artifacts** | removes the `<stem>_build/` directory |

Keyboard shortcuts (only active in `.pylon` files):

- `Ctrl/Cmd+Shift+R` — compile and run
- `Ctrl/Cmd+Shift+C` — compile

All four commands also appear in the editor context menu (right-click) under
a Pylon group.

Compiler output (stdout + stderr) is streamed to a **Pylon** output channel.
If pylonc reports translation errors with a line number, those are mapped
into VS Code diagnostics tagged `pylonc` (distinct from the live `pylon`
diagnostics) so you can click through to the offending line.

### File icon

A Pylon file icon (`icons/pylon-file.png` for light themes,
`icons/pylon-file-dark.png` for dark themes — both 32×32 PNG, derived
from the simplified "no glass" logo variant) is shown next to `.pylon`
files in the Explorer. The same simplified logo is used for both themes
because it reads cleanly at small sizes where the detailed main logo
would lose detail. The extension/marketplace icon
(`icons/extension-icon.png`, 256×256 PNG) uses the full "Pylon Logo".

### Editor defaults for `.pylon` files

The extension sets sensible defaults via `configurationDefaults`:

- 4-space indentation, `insertSpaces: true`
- 100-column ruler
- Semantic highlighting enabled
- `detectIndentation` disabled (so the explicit setting wins)

## Installation

### Option A: install from source (recommended for now)

```bash
cd vscode-pylon
npm install          # installs @types/vscode and typescript
npm run compile      # tsc -p ./  -> writes out/*.js

# Then in VS Code:
#   1. Open the vscode-pylon folder
#   2. Press F5 (or Run > Start Debugging)
#   3. A new "Extension Development Host" window opens with the extension loaded
```

For a permanent install, package it as a `.vsix` and install that:

```bash
npm install -g @vscode/vsce
vsce package          # produces pylon-0.1.0.vsix
code --install-extension pylon-0.1.0.vsix
```

### Option B: from the built output

The `out/` directory ships pre-compiled JS, so you can also just copy the
whole `vscode-pylon/` folder into `~/.vscode/extensions/pylon/` and reload
VS Code — no build step required. (Useful if you don't have Node available.)

## Configuration

Open Settings (`Ctrl/Cmd+,`) and search `pylon`:

| Setting | Default | Description |
| --- | --- | --- |
| `pylon.pyloncPath` | `"python3 pylonc.py"` | Command used to invoke the Pylon compiler. Set to an absolute path to your `pylonc.py`, or a wrapper script. Tokens are split on spaces; quote a path containing spaces with `"..."`. If argv[0] is bare `python3`/`python`, it is replaced by the resolved interpreter (see `pylon.pythonPath`). |
| `pylon.pythonPath` | `""` | Absolute path to the Python interpreter to use when running pylonc. Takes precedence over the Python extension's selected interpreter. Leave empty to auto-discover: the extension checks the Python extension's active interpreter, then `python.defaultInterpreterPath`. |
| `pylon.enableDiagnostics` | `true` | Run the live tokenizer/parser on every keystroke and report syntax errors in the Problems panel. |
| `pylon.debounceMs` | `300` | Milliseconds to wait after the last keystroke before re-checking. Lower = more responsive, higher = less CPU. |
| `pylon.devMode` | `false` | Pass `--dev` to pylonc — compiles the generated C at `-O0` for faster edit/compile loops at the cost of slower runtime. |
| `pylon.showOutputPanel` | `true` | Show the Pylon output channel with compiler stdout/stderr after each build. |

### PATH handling and the Python interpreter

When VS Code's extension host launches a subprocess (like pylonc), it runs
in a **non-login shell** — PATH often lacks the entries your terminal init
scripts add (Homebrew's `/opt/homebrew/bin`, pyenv shims, venv bins). This
caused the original "No such file or directory: 'cython'" error: pylonc
called the bare `cython` CLI, which wasn't on the stripped PATH even though
the `cython` Python package was installed.

The fix has two layers:

1. **`pylonc.py` now uses `sys.executable -m cython`** instead of the bare
   `cython` CLI. Since `sys.executable` is the interpreter that's already
   running pylonc (and therefore the one with cython installed), the
   subprocess finds cython regardless of PATH. The same fix is applied to
   the `.so` runner (`sys.executable -c "import ..."`) so the program is
   executed by the same interpreter that compiled it.

2. **The extension sanitizes PATH for the pylonc subprocess**, appending
   `/usr/local/bin`, `/usr/bin`, `/opt/homebrew/bin`, and the macOS Framework
   Python bin dir if they aren't already present. This is belt-and-suspenders
   so the C compiler (`cc`/`gcc`/`clang`) is always findable. pylonc itself
   also has a `_resolve_compiler()` helper that respects the `CC` env var
   and falls back across `cc` → `gcc` → `clang`, with a clear error
   ("No C compiler found. Tried: cc, gcc, clang. Install Xcode Command Line
   Tools…") if none is available.

If you still hit a "command not found" error, the most reliable fix is to
set `pylon.pythonPath` to the absolute path of the interpreter that has
cython installed, e.g. `/Users/wilby/.venv/bin/python3` or
`/opt/homebrew/bin/python3.12`.

## Const safety

A `const` declaration (`const Type name = expr;`) is meant to be immutable
after its initial binding. Since the translator emits it as a plain `cdef`
(Cython has no useful `const` qualifier for Python objects), nothing at the C
level enforces it — so the extension and `pylonc.py` now perform a
compile-time / live check.

The following are flagged as errors at both compile time and as live
squiggly diagnostics:

```pylon
const int MAX = 100;
MAX = 200;        // ERROR: cannot reassign const 'MAX'
MAX += 5;         // ERROR: augmented assignment to const
del MAX;          // ERROR: cannot 'del' const
MAX = x = 5;      // ERROR: multi-target assignment hits a const
```

**Error-recovery exception.** Reassigning a const inside an `except`,
`else`, or `finally` block of a `try` is **allowed**, because those blocks
are the recovery path where re-binding a "constant" to a fallback value is
the whole point of the handler:

```pylon
const str cfg = load_config();
try {
    use(cfg);
} except {
    cfg = "DEFAULT";   // OK - recovery path, rebind allowed
    use(cfg);
}
```

Reassigning inside the `try` body itself is still an error.

**Scoping.** Module-level consts are visible to nested functions (Python
closure semantics). A local const in one function doesn't interfere with a
same-named local in another. Attribute and subscript assignments
(`xs.append(4)` where `xs` is const, or `xs[0] = 5`) are intentionally NOT
flagged — `const` binds the name, not the object it refers to. Use a
non-const container type if you need to mutate its contents.

## Return-type checking

When a function declares a return type (e.g. `def string f() { ... }`),
Cython enforces it at run time and raises a Python `TypeError` ("Expected
str, got int") if a `return` hands back the wrong type. That's a
Cython-level error pointing into the generated `.pyx`, which is confusing
to read. The extension and `pylonc.py` now catch the common case at
compile time:

```pylon
def string f() {
    return 2;     // ERROR: return type mismatch: function declared to
}                 //        return 'string' but expression looks like 'int'.
```

You'll see a red squiggle under `2` as you type, and the build fails with
a clear message pointing to the exact line.

**What's inferred.** The check recognises:

- Integer, float, and complex literals (`2`, `0x1F`, `2.5`, `1e10`, `1j`)
- String and bytes literals (`"hi"`, `'hi'`, `b"hi"`, `r"..."`, `f"..."`)
- `True`, `False`, `None`
- Builtin constructor calls (`int(...)`, `str(...)`, `list(...)`, `dict(...)`,
  `set(...)`, `tuple(...)`, `bytes(...)`, `bytearray(...)`, `range(...)`,
  `complex(...)`, `bool(...)`, `frozenset(...)`, `memoryview(...)`)
- Literal displays: `[]`, `()`, `(a, b)`, `{}`, `{1: 2}`, `{1, 2}`

**Bare `return;` is always allowed**, even in a function declared to
return a non-`NoneType` type. It's equivalent to `return None`, which
Cython tolerates for object return types — and the user explicitly asked
not to flag it.

**Conservative by design.** Anything that can't be proven from the
literal alone — variables, arithmetic, non-constructor function calls,
parenthesised single expressions like `(1)` — is left alone. Better to
miss a case than to false-flag valid code. The Cython runtime check
still catches anything we miss, so you'll never get silently wrong
behaviour.

## Translating to pure Python

Sometimes you don't want to compile to a native module — you want
readable Python you can read, share, or run with a plain interpreter.
The extension ships a second translator, `pylon2py.py`, that turns
`.pylon` source into idiomatic pure Python with PEP 484 type hints:

| Pylon                         | Pure Python                |
| ----------------------------- | -------------------------- |
| `int x = 5;`                  | `x: int = 5`               |
| `const int MAX = 100;`        | `MAX: int = 100`           |
| `def int f(int n) { ... }`    | `def f(n: int) -> int:`    |
| `def NoneType g() { ... }`   | `def g() -> None:`         |

It reuses `pylonc.py`'s tokenizer, parser, AST, and semantic checks
(const-safety + return-type), so the two translators never disagree on
what's valid — only the emitter differs. `const` is a Pylon-only
concept (Python has no `const`), so the type hint is preserved and the
const-safety check still runs at translation time.

**From the editor:** right-click in any `.pylon` file → **Pylon:
Translate to Python** (also in the Command Palette under the same
name). The translated Python opens in a new untitled editor for you to
review and save where you like. It does NOT compile or run anything,
and it does NOT write a `.py` file next to your source (so it can't
clobber an existing file). Translation errors appear in the Pylon
output panel and as Problems-panel diagnostics.

**From the command line:**

```bash
# Write <stem>.py next to the .pylon file
python3 pylon2py.py hello.pylon

# Print to stdout
python3 pylon2py.py --stdout hello.pylon

# Read from stdin
cat hello.pylon | python3 pylon2py.py -
```

## Project layout

```
vscode-pylon/
├── package.json                  # extension manifest (all contributions)
├── tsconfig.json                 # TypeScript build config
├── language-configuration.json  # brackets, autoclose, comments, indent
├── .vscodeignore                 # what to exclude from the .vsix
├── .gitignore
├── syntaxes/
│   └── pylon.tmLanguage.json     # TextMate grammar
├── snippets/
│   └── pylon.json                # snippet definitions
├── icons/
│   ├── extension-icon.png        # 256x256 main logo (extension + marketplace icon)
│   ├── extension-icon-128.png    # 128x128 smaller marketplace variant
│   ├── pylon-file.png             # 32x32 simple-logo file icon (light theme)
│   ├── pylon-file-dark.png        # 32x32 simple-logo file icon (dark theme)
│   ├── pylon-file-16.png          # 16x16 small-DPI variant
│   └── pylon-file-dark-16.png     # 16x16 small-DPI dark variant
├── src/
│   ├── extension.ts              # entrypoint: diagnostics + commands
│   ├── checker.ts                # pure-TS Pylon tokenizer + parser (no vscode dep)
│   └── vscode-bridge.ts          # converts PylonDiagnostic -> vscode.Diagnostic
├── out/                          # compiled JS (committed; no build needed)
│   ├── extension.js
│   ├── checker.js
│   └── vscode-bridge.js
└── sample/                       # sample .pylon files for testing
    ├── hello.pylon
    ├── features.pylon
    └── benchmark.pylon
```

## Development

```bash
npm run compile    # one-shot build
npm run watch      # rebuild on save
```

The checker (`src/checker.ts`) has no `vscode` import on purpose, so it can
be unit-tested with plain Node. A smoke test lives at
`scripts/test_checker.js` (in the parent Pylon project) — 15 cases covering
valid source, missing semicolons, missing braces, keyword-as-name,
unterminated strings, missing parens, and the `in`/`is None` false-positive
guards. Run it with:

```bash
node /path/to/test_checker.js
```

## Icons

The extension ships with two Pylon logos (provided by the user):

- **`icons/extension-icon.png`** — the main "Pylon Logo" (256×256 PNG).
  Used as the extension's display icon in the Extensions view and the
  marketplace tile.
- **`icons/pylon-file.png`** / **`icons/pylon-file-dark.png`** — the
  "Pylon Simple Logo No Glass" variant (32×32 PNG), used as the file
  icon next to `.pylon` files in the explorer. The same simplified
  logo is used for both light and dark themes; it reads well at small
  sizes where the detailed main logo would muddy.

To replace either logo with your own, drop the new image at the same
path (keeping the dimensions: 256×256 for the extension icon, 32×32
for the file icon) and reload the window. The `package.json` already
references these paths, so no manifest change is needed.

## Known limitations

- The live checker is permissive about expression-level grammar; full type
  checking is delegated to `pylonc` at compile time. Run a build to get
  authoritative errors.
- Semantic highlighting is enabled by default but only structural tokens
  (functions, classes, types) get semantic scopes; full semantic analysis
  (e.g. "this variable is an `int`") would require a language server.
- The `pyloncPath` setting is split on whitespace with simple quote
  handling; very complex invocations may need a wrapper script.

## License

MIT
