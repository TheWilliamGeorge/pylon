/**
 * Pylon VS Code extension entrypoint.
 *
 * Responsibilities:
 *   - Live diagnostics: re-tokenize + structurally check the active .pylon
 *     document on every edit (debounced) and surface errors in the
 *     Problems panel.
 *   - Commands: compile / compile --embed / compile & run / clean build
 *     artifacts, all of which shell out to pylonc. Plus "Translate to
 *     Python", which shells out to the bundled pylon2py.py to produce
 *     pure Python with PEP 484 type hints (no compilation, no run).
 *
 * The compiler invocation is configurable via `pylon.pyloncPath` (default
 * `python3 pylonc.py`); users can point it at an absolute path or a wrapper
 * script.
 */

import * as vscode from "vscode";
import * as path from "path";
import * as fs from "fs";
import * as cp from "child_process";
import { checkPylonSource } from "./checker";
import { toVsDiagnostics } from "./vscode-bridge";

let diagnosticCollection: vscode.DiagnosticCollection;
let outputChannel: vscode.OutputChannel;
let debounceTimer: NodeJS.Timeout | undefined;

export function activate(context: vscode.ExtensionContext) {
    outputChannel = vscode.window.createOutputChannel("Pylon");
    diagnosticCollection =
        vscode.languages.createDiagnosticCollection("pylon");
    context.subscriptions.push(outputChannel, diagnosticCollection);

    // --- live diagnostics ------------------------------------------------
    const doCheck = (doc: vscode.TextDocument) => {
        if (doc.languageId !== "pylon") return;
        const cfg = vscode.workspace.getConfiguration("pylon");
        if (!cfg.get<boolean>("enableDiagnostics", true)) {
            diagnosticCollection.delete(doc.uri);
            return;
        }
        const diags = checkPylonSource(doc.getText());
        diagnosticCollection.set(doc.uri, toVsDiagnostics(diags, doc));
    };

    const scheduleCheck = (doc: vscode.TextDocument) => {
        if (doc.languageId !== "pylon") return;
        const cfg = vscode.workspace.getConfiguration("pylon");
        const ms = cfg.get<number>("debounceMs", 300);
        if (debounceTimer) clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => doCheck(doc), ms);
    };

    context.subscriptions.push(
        vscode.workspace.onDidChangeTextDocument(e => scheduleCheck(e.document)),
        vscode.workspace.onDidOpenTextDocument(doCheck),
        vscode.workspace.onDidCloseTextDocument(
            doc => diagnosticCollection.delete(doc.uri)),
        vscode.workspace.onDidSaveTextDocument(doCheck),
    );

    // Run an initial check on every already-open .pylon document.
    vscode.workspace.textDocuments.forEach(doCheck);

    // --- commands --------------------------------------------------------
    context.subscriptions.push(
        vscode.commands.registerCommand("pylon.compile",
            () => runPylonc(false, false)),
        vscode.commands.registerCommand("pylon.compileEmbed",
            () => runPylonc(true, false)),
        vscode.commands.registerCommand("pylon.run",
            () => runPylonc(false, true)),
        vscode.commands.registerCommand("pylon.clean", cleanBuildArtifacts),
        vscode.commands.registerCommand("pylon.translateToPython",
            translateToPython),
    );
}

export function deactivate() {
    if (debounceTimer) clearTimeout(debounceTimer);
}

// --- command implementations ---------------------------------------------

function activePylonDoc(): vscode.TextDocument | undefined {
    const ed = vscode.window.activeTextEditor;
    if (!ed || ed.document.languageId !== "pylon") {
        void vscode.window.showErrorMessage(
            "Pylon: no active .pylon file.");
        return;
    }
    return ed.document;
}

/**
 * Resolve the Python interpreter to use when invoking pylonc, in priority
 * order:
 *   1. `pylon.pythonPath` (explicit setting) - if set, always wins.
 *   2. The Python extension's selected interpreter for the workspace, if
 *      the Python extension is installed and exposes its API.
 *   3. `python.defaultInterpreterPath` from workspace settings (the
 *      Python extension's persisted setting, readable without the API).
 *   4. Empty string - fall back to whatever argv[0] was in pyloncPath
 *      (usually bare "python3").
 *
 * Returns an absolute path when possible, or "" if no override applies.
 */
function resolvePythonInterpreter(cfg: vscode.WorkspaceConfiguration): string {
    // 1. Explicit pylon.pythonPath setting.
    const explicit = cfg.get<string>("pythonPath", "");
    if (explicit && explicit.trim()) return explicit.trim();

    // 2. Python extension's active interpreter (if the extension is
    //    installed and exported its API).
    try {
        const pyExt = vscode.extensions.getExtension(
            "ms-python.python");
        if (pyExt && pyExt.isActive) {
            const api: unknown = pyExt.exports;
            // The Python extension's exports vary by version; we only use
            // it opportunistically, so a soft cast + feature check is fine.
            const settings = (api as {
                environments?: {
                    getActiveEnvironmentPath?: () => { path: string };
                };
            })?.environments;
            const active = settings?.getActiveEnvironmentPath?.();
            if (active && active.path) return active.path;
        }
    } catch {
        // Python extension API shape changed, or not installed. Fall through.
    }

    // 3. python.defaultInterpreterPath setting (persisted by the Python
    //    extension; readable from any extension without the API).
    const pyCfg = vscode.workspace.getConfiguration("python");
    const defaultInterp = pyCfg.get<string>("defaultInterpreterPath", "");
    if (defaultInterp && defaultInterp.trim()) return defaultInterp.trim();

    // 4. No override.
    return "";
}

function buildPyloncCommand(args: string[]): string {
    const cfg = vscode.workspace.getConfiguration("pylon");
    const cmdLine = cfg.get<string>("pyloncPath", "python3 pylonc.py");
    // Split the configured command into argv (respecting simple quoting).
    const parts = cmdLine.match(/"[^"]*"|\S+/g) || [];
    const argv = parts.map(p => p.replace(/^"(.*)"$/, "$1"));
    return JSON.stringify([...argv, ...args]);
}

function runPylonc(embed: boolean, run: boolean) {
    const doc = activePylonDoc();
    if (!doc) return;
    // Save first - otherwise we compile stale source.
    if (doc.isDirty) {
        void doc.save().then(saved => {
            if (saved) invokePylonc(doc, embed, run);
            else vscode.window.showWarningMessage(
                "Pylon: file not saved; skipping compile.");
        });
    } else {
        invokePylonc(doc, embed, run);
    }
}

function invokePylonc(doc: vscode.TextDocument, embed: boolean, run: boolean) {
    const cfg = vscode.workspace.getConfiguration("pylon");
    const devMode = cfg.get<boolean>("devMode", false);
    const showOutput = cfg.get<boolean>("showOutputPanel", true);
    const cmdLine = cfg.get<string>("pyloncPath", "python3 pylonc.py");
    const parts = cmdLine.match(/"[^"]*"|\S+/g) || [];
    const argv = parts.map(p => p.replace(/^"(.*)"$/, "$1"));

    const args: string[] = [];
    if (embed) args.push("--embed");
    if (devMode) args.push("--dev");
    // Always pass --no-cache so the user sees real compile errors when they
    // explicitly invoke a build. The cache is for repeat runs, not for
    // explicit commands.
    args.push("--no-cache");
    if (!run) args.push("--no-run");
    args.push(doc.uri.fsPath);

    if (showOutput) {
        outputChannel.show(true);
        outputChannel.appendLine(
            `>>> ${cmdLine} ${args.map(a => a.includes(" ") ? `"${a}"` : a).join(" ")}`);
    }
    const cwd = path.dirname(doc.uri.fsPath);

    // Resolve the Python interpreter to use as argv[0] of the pylonc command.
    // The default `pyloncPath` is "python3 pylonc.py", which works on a shell
    // with a sane PATH. But VS Code's extension host often runs with a
    // stripped PATH (no login shell init), so bare `python3` may resolve to
    // the wrong interpreter or none at all. We honor, in order:
    //   1. pylon.pyloncPath (if the user set it, they know what they want)
    //      -> but if argv[0] is exactly "python3" or "python", we still
    //         override with the resolved interpreter below, since that's the
    //         whole point of the setting.
    //   2. pylon.pythonPath (explicit setting, takes precedence over the
    //      Python extension's pick).
    //   3. The Python extension's selected interpreter
    //      (workspace setting "python.defaultInterpreterPath", or the active
    //      interpreter reported by the Python extension's API if available).
    //   4. The "python3" / "python" that was in pyloncPath (last resort).
    const resolvedPython = resolvePythonInterpreter(cfg);

    // If argv[0] is a bare "python3"/"python" and we resolved a better
    // interpreter, substitute it. Leave absolute paths alone (the user set
    // pyloncPath explicitly to a real interpreter).
    const finalArgv = [...argv];
    if (resolvedPython && /^python3?(\.\d+)?$/.test(finalArgv[0])) {
        finalArgv[0] = resolvedPython;
    }

    // Build the subprocess environment. Copy process.env and ensure PATH
    // includes common system bin dirs, so the compiler (cc/gcc/clang) and
    // any shell-init-only tools remain visible even under a stripped PATH.
    // pylonc itself now uses sys.executable for its own subprocesses, so
    // this is belt-and-suspenders for the rare case where argv[0] IS an
    // absolute interpreter but its bin dir isn't on PATH.
    const childEnv = { ...process.env };
    const extraPaths = [
        "/usr/local/bin", "/usr/bin", "/bin",
        "/usr/sbin", "/sbin",
        "/opt/homebrew/bin", "/opt/homebrew/sbin",  // macOS Apple Silicon
        "/Library/Frameworks/Python.framework/Versions/Current/bin",
    ];
    const pathSep = process.platform === "win32" ? ";" : ":";
    const existingPath = (childEnv.PATH || "").split(pathSep);
    for (const p of extraPaths) {
        if (p && !existingPath.includes(p)) existingPath.push(p);
    }
    childEnv.PATH = existingPath.join(pathSep);

    const proc = cp.spawn(finalArgv[0], [...finalArgv.slice(1), ...args], {
        cwd,
        env: childEnv,
    });
    let stdout = "";
    let stderr = "";
    proc.stdout.on("data", d => {
        const s = d.toString();
        stdout += s;
        if (showOutput) outputChannel.append(s);
    });
    proc.stderr.on("data", d => {
        const s = d.toString();
        stderr += s;
        if (showOutput) outputChannel.append(s);
    });
    proc.on("close", code => {
        if (showOutput) {
            outputChannel.appendLine(
                `<<< exit ${code}` + (code === 0 ? "" : " (non-zero)"));
        }
        if (code === 0) {
            void vscode.window.showInformationMessage(
                `Pylon: ${embed ? "executable" : "extension module"} built.`);
        } else {
            void vscode.window.showErrorMessage(
                `Pylon: build failed (exit ${code}). See Pylon output panel.`);
        }
        // Refresh diagnostics from the actual compiler errors, if pylonc
        // printed any. pylonc formats errors as "pylonc: <kind> error:\n<msg>".
        if (stderr) {
            parsePyloncErrors(stderr, doc);
        }
    });
}

/**
 * Translate the active .pylon file to pure Python (with PEP 484 type hints)
 * and open the result in a new untitled editor. Does NOT run the code.
 *
 * Shells out to the bundled `scripts/pylon2py.py`, which reuses pylonc.py's
 * tokenizer/parser/AST and the const-safety + return-type semantic checks,
 * then emits plain Python via a separate emitter. The same Python
 * interpreter resolution as `invokePylonc` applies.
 */
function translateToPython() {
    const doc = activePylonDoc();
    if (!doc) return;

    // Save first - otherwise we translate stale source.
    if (doc.isDirty) {
        void doc.save().then(saved => {
            if (saved) invokePylon2py(doc);
            else vscode.window.showWarningMessage(
                "Pylon: file not saved; skipping translation.");
        });
    } else {
        invokePylon2py(doc);
    }
}

function invokePylon2py(doc: vscode.TextDocument) {
    const cfg = vscode.workspace.getConfiguration("pylon");
    const showOutput = cfg.get<boolean>("showOutputPanel", true);
    // The translator ships with the extension under scripts/. pylon2py.py
    // imports pylonc.py from the same directory (it inserts its own dir
    // into sys.path), so we just need to point the interpreter at it.
    const extRoot = vscode.extensions.getExtension("pylon.pylon")?.extensionPath
        ?? path.dirname(path.dirname(__dirname));
    const pylon2pyPath = path.join(extRoot, "scripts", "pylon2py.py");

    if (!fs.existsSync(pylon2pyPath)) {
        void vscode.window.showErrorMessage(
            `Pylon: bundled translator not found at ${pylon2pyPath}. ` +
            `The extension may be corrupted; try reinstalling.`);
        return;
    }

    // Resolve the Python interpreter (same priority order as compile).
    const resolvedPython = resolvePythonInterpreter(cfg);
    const pyArgv0 = resolvedPython || "python3";

    // Build the subprocess environment (mirror invokePylonc: ensure common
    // bin dirs are on PATH so the interpreter and its imports resolve).
    const childEnv = { ...process.env };
    const extraPaths = [
        "/usr/local/bin", "/usr/bin", "/bin",
        "/usr/sbin", "/sbin",
        "/opt/homebrew/bin", "/opt/homebrew/sbin",
        "/Library/Frameworks/Python.framework/Versions/Current/bin",
    ];
    const pathSep = process.platform === "win32" ? ";" : ":";
    const existingPath = (childEnv.PATH || "").split(pathSep);
    for (const p of extraPaths) {
        if (p && !existingPath.includes(p)) existingPath.push(p);
    }
    childEnv.PATH = existingPath.join(pathSep);

    const args = ["--stdout", doc.uri.fsPath];
    const cwd = path.dirname(doc.uri.fsPath);

    if (showOutput) {
        outputChannel.show(true);
        outputChannel.appendLine(
            `>>> ${pyArgv0} ${pylon2pyPath} ` +
            args.map(a => a.includes(" ") ? `"${a}"` : a).join(" "));
    }

    const proc = cp.spawn(pyArgv0, [pylon2pyPath, ...args], {
        cwd,
        env: childEnv,
    });
    let stdout = "";
    let stderr = "";
    proc.stdout.on("data", d => { stdout += d.toString(); });
    proc.stderr.on("data", d => {
        const s = d.toString();
        stderr += s;
        if (showOutput) outputChannel.append(s);
    });
    proc.on("close", code => {
        if (showOutput) {
            outputChannel.appendLine(
                `<<< exit ${code}` + (code === 0 ? "" : " (non-zero)"));
        }
        if (code === 0) {
            // Open the translated Python in a new untitled editor so the
            // user can review and save it where they like. We don't write
            // a .py next to the source automatically - that could clobber
            // an existing file.
            void vscode.workspace.openTextDocument({ content: stdout, language: "python" })
                .then(newDoc => {
                    void vscode.window.showTextDocument(newDoc, { preview: false });
                    void vscode.window.showInformationMessage(
                        "Pylon: translated to Python (opened in new editor).");
                }, err => {
                    void vscode.window.showErrorMessage(
                        `Pylon: failed to open translated document: ${err}`);
                });
        } else {
            void vscode.window.showErrorMessage(
                `Pylon: translation failed (exit ${code}). ` +
                `See Pylon output panel.`);
            // Surface translation errors as diagnostics too, so the user
            // sees exactly which line is at fault.
            if (stderr) parsePyloncErrors(stderr, doc);
        }
    });
}

function parsePyloncErrors(stderr: string, doc: vscode.TextDocument) {
    // pylonc prints errors like:
    //   pylonc: translation error: Expected ; but got NAME('def') at line 7
    //   pylonc: gcc compile error: ...
    // We only know how to map translation errors (which carry a line number).
    const diags = diagnosticCollection.get(doc.uri) ?? [];
    const newDiags: vscode.Diagnostic[] = [];
    const re = /pylonc:\s+(\w+) error:\s+(.*?)(?=\npylonc:|$)/gs;
    let m: RegExpExecArray | null;
    while ((m = re.exec(stderr)) !== null) {
        if (m === null) break;
        const kind = m[1];
        const body = m[2].trim();
        // Try to extract a line number.
        const lm = body.match(/line (\d+)/);
        if (lm) {
            const line = parseInt(lm[1], 10) - 1;
            const range = new vscode.Range(
                new vscode.Position(Math.max(0, line), 0),
                new vscode.Position(Math.max(0, line), Number.MAX_SAFE_INTEGER));
            const d = new vscode.Diagnostic(
                range,
                `Pylon ${kind} error: ${body}`,
                vscode.DiagnosticSeverity.Error);
            d.source = "pylonc";
            newDiags.push(d);
        }
    }
    if (newDiags.length) {
        diagnosticCollection.set(doc.uri, [...diags, ...newDiags]);
    }
}

function cleanBuildArtifacts() {
    const doc = activePylonDoc();
    if (!doc) return;
    const stem = path.basename(doc.uri.fsPath, ".pylon");
    const dir = path.dirname(doc.uri.fsPath);
    const buildDir = path.join(dir, `${stem}_build`);
    if (!fs.existsSync(buildDir)) {
        void vscode.window.showInformationMessage(
            `Pylon: no build dir to clean (${buildDir} does not exist).`);
        return;
    }
    try {
        fs.rmSync(buildDir, { recursive: true, force: true });
        void vscode.window.showInformationMessage(
            `Pylon: removed ${buildDir}`);
    } catch (e) {
        void vscode.window.showErrorMessage(
            `Pylon: failed to remove ${buildDir}: ${(e as Error).message}`);
    }
}
