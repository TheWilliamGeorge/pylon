/**
 * Bridge between the pure-TypeScript Pylon checker (in checker.ts) and the
 * VS Code Diagnostic API. Kept separate so checker.ts has no `vscode`
 * dependency and can be unit-tested with plain Node.
 */

import * as vscode from "vscode";
import { PylonDiagnostic } from "./checker";

/** Convert internal diagnostics into VS Code Diagnostics. */
export function toVsDiagnostics(
    diags: PylonDiagnostic[],
    document: vscode.TextDocument
): vscode.Diagnostic[] {
    return diags.map(d => {
        const startLine = Math.max(0, d.startLine);
        const endLine = Math.max(0, d.endLine);
        const lineCount = document.lineCount;
        const startLineObj = startLine < lineCount
            ? document.lineAt(startLine)
            : document.lineAt(lineCount - 1);
        const endLineObj = endLine < lineCount
            ? document.lineAt(endLine)
            : document.lineAt(lineCount - 1);
        const start = startLineObj.range.start
            .translate(0, Math.max(0, d.startCol));
        const end = endLineObj.range.start
            .translate(0, Math.max(0, d.endCol));
        const range = new vscode.Range(start, end);
        const severity =
            d.severity === "error" ? vscode.DiagnosticSeverity.Error :
            d.severity === "warning" ? vscode.DiagnosticSeverity.Warning :
            vscode.DiagnosticSeverity.Information;
        const diag = new vscode.Diagnostic(range, d.message, severity);
        diag.source = "pylon";
        return diag;
    });
}
