/**
 * Pylon diagnostic checker.
 *
 * A faithful, lightweight port of pylonc.py's lexer + the error-detection
 * parts of its parser. This is NOT a full parser: it deliberately skips
 * the AST construction and only emits the *errors* the real pylonc would
 * raise. The goal is to surface problems live, as the user types, without
 * launching the (slow) real compiler on every keystroke.
 *
 * IMPORTANT: this module is PURE TypeScript - no `vscode` import. That way
 * it can be unit-tested with plain Node and reused outside the extension
 * host. The VS Code -> PylonDiagnostic bridge lives in vscode-bridge.ts.
 *
 * What we check (matches pylonc.py's PylonError sites):
 *  - lexer: unexpected characters, unterminated strings, bad string prefixes
 *  - statements: missing semicolons, missing closing braces, dangling keywords
 *  - declarations: keyword used as a name, unknown type name
 *  - function defs: missing parens, bad return type, unbalanced params
 *  - class defs: missing body braces
 *  - control flow: if/for/while missing `{`, missing `;` after return/break/etc.
 *
 * The checker is intentionally permissive about expression grammar - we
 * delegate full expression validation to pylonc.py itself, which runs on
 * actual compile. Our job here is to catch the structural mistakes that
 * cause the most confusing compile errors.
 */


// --- keyword/type tables (kept in sync with pylonc.py) --------------------

const KEYWORDS = new Set<string>([
    "def", "if", "elif", "else", "while", "for", "return", "break",
    "continue", "pass", "import", "from", "as", "class", "global",
    "nonlocal", "del", "with", "try", "except", "finally", "raise",
    "assert", "lambda", "yield", "True", "False", "None", "const",
]);

const WORD_OPS = new Set<string>(["and", "or", "not", "in", "is"]);

const PRIMITIVE_TYPES = new Set<string>(["int", "float", "boolean"]);
const OBJECT_TYPES = new Set<string>([
    "string", "str", "bool", "complex", "bytes", "bytearray", "list",
    "tuple", "dict", "set", "frozenset", "range", "memoryview",
    "NoneType", "object",
]);
const VALID_TYPE_NAMES = new Set<string>([
    ...PRIMITIVE_TYPES, ...OBJECT_TYPES,
]);

const BUILTIN_FUNCS = new Set<string>([
    "abs", "all", "any", "ascii", "bin", "bool", "bytearray", "bytes",
    "callable", "chr", "classmethod", "compile", "complex", "delattr",
    "dict", "dir", "divmod", "enumerate", "eval", "exec", "filter",
    "float", "format", "frozenset", "getattr", "globals", "hasattr",
    "hash", "help", "hex", "id", "input", "int", "isinstance",
    "issubclass", "iter", "len", "list", "locals", "map", "max",
    "memoryview", "min", "next", "object", "oct", "open", "ord", "pow",
    "print", "property", "range", "repr", "reversed", "round", "set",
    "setattr", "slice", "sorted", "staticmethod", "str", "sum", "super",
    "tuple", "type", "vars", "zip",
]);

// --- token -----------------------------------------------------------------

type TokenKind =
    | "NAME" | "NUMBER" | "STRING" | "FSTRING" | "OP"
    | "PUNCT" | "NEWLINE" | "EOF";

interface Token {
    kind: TokenKind;
    value: string;
    line: number;
    col: number;
    end: number; // offset of the character just past the token
    start: number;
}

// --- diagnostics ----------------------------------------------------------

export interface PylonDiagnostic {
    startLine: number; // 0-based
    startCol: number;  // 0-based
    endLine: number;
    endCol: number;
    message: string;
    severity: "error" | "warning" | "hint";
}

// --- lexer -----------------------------------------------------------------

function isNameStart(c: string): boolean { return /[A-Za-z_]/.test(c); }
function isNameCont(c: string): boolean { return /[A-Za-z0-9_]/.test(c); }
function isDigit(c: string): boolean { return c >= "0" && c <= "9"; }

function peekStringPrefix(src: string, i: number): boolean {
    let j = i;
    while (j < src.length && "fFrRbBuU".includes(src[j])) j++;
    return j < src.length && (src[j] === "'" || src[j] === '"');
}

/**
 * Lex a string literal starting at i. `startI` is the offset of the first
 * prefix char (or the opening quote if no prefix). Returns the token end
 * offset, or throws {message, line, col} on unterminated string.
 */
function lexString(src: string, startI: number, line: number, col: number,
                  tokens: Token[], doc: PylonDiagnostic[]): number {
    let i = startI;
    const n = src.length;
    // Consume prefix.
    let prefix = "";
    while (i < n && "fFrRbBuU".includes(src[i])) { prefix += src[i]; i++; }
    if (i >= n) {
        doc.push({ startLine: line - 1, startCol: col - 1, endLine: line - 1,
            endCol: col, message: "Unterminated string literal",
            severity: "error" });
        return n;
    }
    const quote = src[i];
    // Triple-quoted?
    if (i + 2 < n && src[i + 1] === quote && src[i + 2] === quote) {
        const close = src.indexOf(quote.repeat(3), i + 3);
        if (close === -1) {
            doc.push({ startLine: line - 1, startCol: col - 1,
                endLine: line - 1, endCol: col,
                message: "Unterminated triple-quoted string",
                severity: "error" });
            return n;
        }
        const end = close + 3;
        const body = src.slice(startI, end);
        // Count newlines in body for line/col tracking.
        const nl = (body.match(/\n/g) || []).length;
        const kind = prefix.toLowerCase().includes("f") ? "FSTRING" : "STRING";
        tokens.push({ kind, value: body, line, col,
            start: startI, end });
        return end;
    }
    // Single-quoted.
    let j = i + 1;
    while (j < n && src[j] !== quote) {
        if (src[j] === "\n") {
            doc.push({ startLine: line - 1, startCol: col - 1,
                endLine: line - 1, endCol: col,
                message: "Unterminated string literal (newline before close)",
                severity: "error" });
            return j;
        }
        if (src[j] === "\\") j++; // skip escaped char
        j++;
    }
    if (j >= n) {
        doc.push({ startLine: line - 1, startCol: col - 1, endLine: line - 1,
            endCol: col, message: "Unterminated string literal",
            severity: "error" });
        return n;
    }
    const end = j + 1;
    const body = src.slice(startI, end);
    const kind = prefix.toLowerCase().includes("f") ? "FSTRING" : "STRING";
    tokens.push({ kind, value: body, line, col, start: startI, end });
    return end;
}

const MULTI_OPS = [
    "**=", "//=", ">>=", "<<=", ":=", "==", "!=", "<=", ">=",
    "**", "//", ">>", "<<", "+=", "-=", "*=", "/=", "%=", "&=", "|=",
    "^=", "->",
].sort((a, b) => b.length - a.length);

export function tokenize(src: string, doc: PylonDiagnostic[]): Token[] {
    const tokens: Token[] = [];
    let i = 0;
    let line = 1;
    let col = 1;
    const n = src.length;
    const at = (j: number) => src[j] ?? "";

    while (i < n) {
        const c = src[i];

        if (c === "\n") { i++; line++; col = 1; continue; }
        if (c === "\r") { i++; continue; }
        if (c === " " || c === "\t") { i++; col++; continue; }
        if (c === "\\" && at(i + 1) === "\n") { i += 2; line++; col = 1; continue; }
        if (c === "#") {
            while (i < n && src[i] !== "\n") i++;
            continue;
        }

        // Strings (incl. prefixes).
        if (c === "'" || c === '"' || (isNameStart(c) && "fFrRbBuU".includes(c) && peekStringPrefix(src, i))) {
            const startCol = col;
            const startLine = line;
            const startI = i;
            i = lexString(src, i, line, col, tokens, doc);
            // Recompute line/col from consumed region.
            const consumed = src.slice(startI, i);
            const nl = (consumed.match(/\n/g) || []).length;
            if (nl > 0) { line += nl; col = consumed.length - consumed.lastIndexOf("\n"); }
            else { col += i - startI; }
            continue;
        }

        // Numbers.
        if (isDigit(c) || (c === "." && isDigit(at(i + 1)))) {
            const start = i;
            if (c === "0" && "xXoObB".includes(at(i + 1))) {
                i += 2;
                while (i < n && (/[a-zA-Z0-9_]/.test(src[i]))) i++;
            } else {
                while (i < n && (isDigit(src[i]) || src[i] === "_")) i++;
                if (i < n && src[i] === ".") {
                    i++;
                    while (i < n && (isDigit(src[i]) || src[i] === "_")) i++;
                }
                if (i < n && (src[i] === "e" || src[i] === "E")) {
                    i++;
                    if (i < n && (src[i] === "+" || src[i] === "-")) i++;
                    while (i < n && (isDigit(src[i]) || src[i] === "_")) i++;
                }
                if (i < n && (src[i] === "j" || src[i] === "J")) i++;
            }
            tokens.push({ kind: "NUMBER", value: src.slice(start, i), line, col,
                start, end: i });
            col += i - start;
            continue;
        }

        // Identifiers / keywords / word-operators / type names.
        if (isNameStart(c)) {
            const start = i;
            while (i < n && isNameCont(src[i])) i++;
            const word = src.slice(start, i);
            const kind = WORD_OPS.has(word) ? "OP" : "NAME";
            tokens.push({ kind, value: word, line, col, start, end: i });
            col += i - start;
            continue;
        }

        // Multi-char operators.
        let matched = false;
        for (const op of MULTI_OPS) {
            if (src.startsWith(op, i)) {
                tokens.push({ kind: "OP", value: op, line, col, start: i, end: i + op.length });
                i += op.length; col += op.length;
                matched = true;
                break;
            }
        }
        if (matched) continue;

        // Structural punctuation + single-char operators.
        if ("{}[]();,.:".includes(c)) {
            tokens.push({ kind: "PUNCT", value: c, line, col, start: i, end: i + 1 });
            i++; col++;
            continue;
        }
        if ("+-*/%<>=&|^~@".includes(c)) {
            tokens.push({ kind: "OP", value: c, line, col, start: i, end: i + 1 });
            i++; col++;
            continue;
        }

        // Anything else is unexpected - pylonc.py raises PylonError here.
        doc.push({
            startLine: line - 1, startCol: col - 1, endLine: line - 1, endCol: col,
            message: `Unexpected character '${c}'`,
            severity: "error",
        });
        i++; col++;
    }
    tokens.push({ kind: "EOF", value: "", line, col, start: i, end: i });
    return tokens;
}

// --- structural checker ---------------------------------------------------

class Parser {
    tokens: Token[];
    pos = 0;
    src: string;
    doc: PylonDiagnostic[] = [];
    /** Const-name scope stack. Bottom entry is module scope; each function
     * body pushes a new set on entry and pops on exit. Names declared const
     * at module level are visible to nested functions (Python closure
     * semantics). */
    constScopes: Set<string>[] = [new Set()];
    /** True while parsing the body of an `except`, `else`, or `finally`
     * block of a `try`. In those blocks, reassigning a const is allowed
     * (the user's "unless the error is being handled" case). */
    inRecovery = false;
    /** Stack of declared return types for the enclosing functions.
     * Bottom entry is `null` (module scope: returns aren't checked). Each
     * `parseFunc` push the function's declared return type on entry and
     * pops on exit. `null` means "no declared type" or "NoneType" - in
     * both cases, any return value is allowed. */
    funcReturnStack: (string | null)[] = [null];

    constructor(tokens: Token[], src: string, doc: PylonDiagnostic[]) {
        this.tokens = tokens;
        this.src = src;
        this.doc = doc;
    }

    peek(off = 0): Token {
        return this.tokens[Math.min(this.pos + off, this.tokens.length - 1)];
    }
    next(): Token { return this.tokens[this.pos++]; }
    atEnd(): boolean { return this.peek().kind === "EOF"; }
    atWord(w: string): boolean {
        const t = this.peek();
        return (t.kind === "NAME" || t.kind === "OP") && t.value === w;
    }
    acceptPunct(p: string): boolean {
        const t = this.peek();
        if (t.kind === "PUNCT" && t.value === p) { this.pos++; return true; }
        return false;
    }
    expectPunct(p: string, ctx: string) {
        const t = this.peek();
        if (t.kind !== "PUNCT" || t.value !== p) {
            this.pushErr(t, `Expected '${p}' but got ${this.describe(t)} ${ctx}`);
            return false;
        }
        this.pos++;
        return true;
    }
    expectName(ctx: string): Token | null {
        const t = this.peek();
        if (t.kind !== "NAME") {
            this.pushErr(t, `Expected a name ${ctx} but got ${this.describe(t)}`);
            return null;
        }
        this.pos++;
        return t;
    }
    describe(t: Token): string {
        if (t.kind === "EOF") return "end of file";
        if (t.kind === "NEWLINE") return "newline";
        if (t.kind === "PUNCT" || t.kind === "OP") return `'${t.value}'`;
        if (t.kind === "STRING" || t.kind === "FSTRING") return "string";
        if (t.kind === "NUMBER") return "number";
        return `NAME('${t.value}')`;
    }
    pushErr(t: Token, msg: string) {
        this.doc.push({
            startLine: t.line - 1, startCol: t.col - 1,
            endLine: t.line - 1, endCol: t.col + Math.max(1, t.value.length) - 1,
            message: msg, severity: "error",
        });
    }

    /** Skip an expression up to (but not consuming) any of `stops`.
     *
     * At depth 0 we also stop on a NAME that looks like the start of a NEW
     * statement: a type name (int/float/string/...) or a statement keyword
     * (def/class/if/for/while/return/...). This catches the most common
     * missing-`;` bug, where the user wrote `int x = 5\nint y = 10;` and
     * pylonc would otherwise silently swallow `int y = 10` into x's
     * initializer, producing bogus Cython.
     *
     * To avoid false positives we are careful:
     *   - A type name followed by `(` is a constructor call (e.g.
     *     `bytearray(b"x")`, `frozenset({...})`, `memoryview(b"abc")`),
     *     NOT a new declaration - we keep skipping.
     *   - Word operators (`in`, `is`, `and`, `or`, `not`, `as`) are
     *     emitted as OP tokens, so they never trigger this NAME branch.
     *   - `True`/`False`/`None` are valid expression operands.
     *
     * `permissive=true` disables the new-statement heuristic entirely. Use
     * it for statements whose own grammar contains keywords that would
     * otherwise look like a new statement: `import`/`from` (which contain
     * the `import` keyword mid-statement), `raise`, `assert`, etc. For
     * those, we just skip to the next `;`.
     */
    skipExprUntil(stops: string[], permissive = false) {
        let depth = 0; // ( [ { depth
        while (true) {
            const t = this.peek();
            if (t.kind === "EOF") return;
            if (depth === 0 && t.kind === "PUNCT" && stops.includes(t.value)) return;
            if (t.kind === "PUNCT" && (t.value === "(" || t.value === "[" || t.value === "{")) {
                depth++;
            } else if (t.kind === "PUNCT" && (t.value === ")" || t.value === "]" || t.value === "}")) {
                if (depth === 0) return; // belongs to caller
                depth--;
            }
            // Depth-0 NAME that begins a new statement: stop here so the
            // caller's expectPunct fires with a clear "missing ;" message
            // rather than silently consuming the next statement. Skip this
            // heuristic in permissive mode (used by import/from/etc).
            else if (!permissive && depth === 0 && t.kind === "NAME"
                     && (VALID_TYPE_NAMES.has(t.value) || KEYWORDS.has(t.value))
                     && t.value !== "True" && t.value !== "False"
                     && t.value !== "None") {
                const nxt = this.peek(1);
                const isCall = nxt.kind === "PUNCT" && (nxt.value === "(" || nxt.value === "[" || nxt.value === ".");
                if (!isCall) return;
            }
            this.pos++;
        }
    }

    parseProgram() {
        while (!this.atEnd()) {
            const before = this.pos;
            this.parseStatement();
            // Safety: if a statement didn't consume any tokens, force-advance
            // to avoid an infinite loop. (Shouldn't happen given current
            // skipExprUntil logic, but defensive against future changes.)
            if (this.pos === before) this.pos++;
        }
    }

    parseStatement() {
        const t = this.peek();
        if (t.kind !== "NAME") {
            // Expression statement or stray punctuation: skip to `;` or `{`.
            this.skipExprUntil([";", "{", "}"]);
            if (this.peek().kind === "PUNCT" && this.peek().value === ";") this.pos++;
            return;
        }
        const kw = t.value;
        switch (kw) {
            case "def": this.parseFunc(); return;
            case "class": this.parseClass(); return;
            case "if": this.parseIf(); return;
            case "while": this.parseWhileOrFor("while"); return;
            case "for": this.parseWhileOrFor("for"); return;
            case "return": this.parseReturn(); return;
            case "break": case "continue": case "pass":
                this.next(); this.expectPunct(";", `after ${kw}`); return;
            case "import": case "from":
                // `from math import sqrt` contains the keyword `import`
                // mid-statement, so use permissive mode (skip to `;`
                // only, ignore the new-statement heuristic).
                this.next(); this.skipExprUntil([";"], true); this.expectPunct(";", `after ${kw}`); return;
            case "raise":
                this.next(); this.skipExprUntil([";"], true); this.expectPunct(";", "after raise"); return;
            case "try": this.parseTry(); return;
            case "with": this.parseWith(); return;
            case "del": this.next(); this.checkConstDel(); this.skipExprUntil([";"], true); this.expectPunct(";", `after ${kw}`); return;
            case "global": case "nonlocal": case "assert":
                this.next(); this.skipExprUntil([";"], true); this.expectPunct(";", `after ${kw}`); return;
            case "const": this.parseConst(); return;
            default:
                if (VALID_TYPE_NAMES.has(kw)) { this.parseDecl(); return; }
                // Bare expression / assignment statement. Before skipping
                // to ';', scan the leading tokens for assignment targets
                // (`NAME =`, `NAME <augop>`, or chains like `a = b = 0`)
                // and flag any that target a name declared `const` in the
                // current or enclosing scope - unless we're inside a
                // try's recovery block (except/else/finally).
                this.checkConstAssignment();
                this.skipExprUntil([";"]);
                {
                    const n = this.peek();
                    if (n.kind === "PUNCT" && n.value === ";") {
                        this.pos++;
                    } else if (n.kind === "PUNCT" && n.value === "}") {
                        // End of block: missing ';' but don't error - the
                        // closing brace is a natural statement terminator.
                        return;
                    } else if (n.kind === "EOF") {
                        return;
                    } else {
                        // The skipper stopped on a NAME that looks like the
                        // start of a new statement. That means this
                        // statement is missing its terminating ';'.
                        this.pushErr(n,
                            `Expected ';' but got ${this.describe(n)} - ` +
                            `missing semicolon at end of statement?`);
                    }
                }
        }
    }

    parseDecl() {
        const typeTok = this.next(); // consume type
        const nameTok = this.expectName("in declaration");
        if (nameTok && KEYWORDS.has(nameTok.value) && nameTok.value !== "_") {
            this.pushErr(nameTok,
                `Cannot use keyword '${nameTok.value}' as variable name`);
        }
        // Optional initializer: skip until `;`.
        this.skipExprUntil([";"]);
        this.expectPunct(";", "after declaration");
    }

    parseConst() {
        this.next(); // consume 'const'
        const typeTok = this.peek();
        if (typeTok.kind !== "NAME" || !VALID_TYPE_NAMES.has(typeTok.value)) {
            this.pushErr(typeTok,
                `Unknown type '${typeTok.value}' in const declaration`);
        } else {
            this.next();
        }
        const nameTok = this.expectName("in const declaration");
        if (nameTok && KEYWORDS.has(nameTok.value) && nameTok.value !== "_") {
            this.pushErr(nameTok,
                `Cannot use keyword '${nameTok.value}' as constant name`);
        }
        // Record this name as const in the current (innermost) scope so the
        // bare-expression branch can flag later reassignments.
        if (nameTok && !KEYWORDS.has(nameTok.value)) {
            this.constScopes[this.constScopes.length - 1].add(nameTok.value);
        }
        if (!this.acceptOp("=")) {
            this.pushErr(this.peek(), "Expected '=' in const declaration");
        } else {
            this.skipExprUntil([";"]);
        }
        this.expectPunct(";", "after const declaration");
    }

    /** True if `name` was declared const in the current scope OR any
     * enclosing scope (module level is always visible to nested
     * functions, per Python closure semantics). */
    isConst(name: string): boolean {
        for (let i = this.constScopes.length - 1; i >= 0; i--) {
            if (this.constScopes[i].has(name)) return true;
        }
        return false;
    }

    /** Augmented-assignment operators that imply mutation of the target. */
    static readonly AUG_OPS = new Set([
        "+=", "-=", "*=", "/=", "//=", "%=", "**=",
        "<<=", ">>=", "&=", "|=", "^=", "@=",
    ]);

    /** Word-like NAME tokens that are NOT variable names (operators or
     * literals), so they shouldn't be mistaken for assignment targets. */
    static readonly NON_NAMES = new Set([
        "and", "or", "not", "in", "is", "as",
        "True", "False", "None",
    ]);

    /** Scan the leading tokens of a bare-expression statement for assignment
     * targets (`NAME =`, `NAME <augop>`, or chains like `a = b = 0`) and
     * flag any that target a const name. Doesn't consume tokens - the
     * caller's skipExprUntil still handles the full statement.
     *
     * We only look at the leftmost run up to the first `=`/augop; tuple
     * unpacking (`a, b = ...`) and attribute/subscript targets (`a.b =`,
     * `a[0] =`) are intentionally ignored, mirroring pylonc.py: a const
     * Pylon name is a C-level binding, and mutating something it refers
     * to is a separate mutability question. */
    checkConstAssignment() {
        if (this.inRecovery) return; // recovery path: rebind allowed
        let i = this.pos;
        const n = this.tokens.length;
        while (i < n) {
            const t = this.tokens[i];
            if (t.kind !== "NAME"
                || Parser.NON_NAMES.has(t.value)
                || KEYWORDS.has(t.value)) {
                break;
            }
            // Peek the next token.
            const nt = this.tokens[Math.min(i + 1, n - 1)];
            if (nt.kind === "OP" && nt.value === "=") {
                if (this.isConst(t.value)) {
                    this.pushErr(t,
                        `Cannot reassign const '${t.value}' (declared const). ` +
                        `To rebind inside error recovery, place it in an ` +
                        `except/else/finally block.`);
                }
                i = i + 2;
                continue;
            }
            if (nt.kind === "OP" && Parser.AUG_OPS.has(nt.value)) {
                if (this.isConst(t.value)) {
                    this.pushErr(t,
                        `Cannot reassign const '${t.value}' (augmented ` +
                        `assignment). To rebind inside error recovery, ` +
                        `place it in an except/else/finally block.`);
                }
                // Augmented assignment has a single target; no further
                // assignment targets on this line.
                break;
            }
            break;
        }
    }

    /** Check the target of a `del` statement (just consumed the `del`
     * keyword). Only flags a single bare NAME; `del a.b` or `del a[0]`
     * don't rebind the const itself. */
    checkConstDel() {
        if (this.inRecovery) return;
        const t = this.peek();
        if (t.kind === "NAME" && !KEYWORDS.has(t.value)
            && !Parser.NON_NAMES.has(t.value) && this.isConst(t.value)) {
            this.pushErr(t,
                `Cannot 'del' const '${t.value}' (declared const).`);
        }
    }

    /** Constructor-call NAMEs whose return type is determined solely by
     * the callable name. Mirrors pylonc.py's _CONSTRUCTOR_TYPES. */
    static readonly CONSTRUCTOR_TYPES: Record<string, string> = {
        "int": "int", "float": "float", "complex": "complex",
        "str": "string", "string": "string",
        "bool": "boolean", "boolean": "boolean",
        "bytes": "bytes", "bytearray": "bytearray",
        "list": "list", "tuple": "tuple", "dict": "dict",
        "set": "set", "frozenset": "frozenset",
        "range": "range", "memoryview": "memoryview",
    };

    /** Parse `return [expr];`. Bare `return;` is always allowed.
     *
     * Before skipping the expression, we scan the leading tokens to infer
     * the literal type (if any) and flag a mismatch with the enclosing
     * function's declared return type. Inference is deliberately
     * conservative - if we can't prove the type from a literal alone, we
     * leave it alone (no false positives). Mirrors pylonc.py's
     * `_infer_return_type`. */
    parseReturn() {
        const retTok = this.next(); // consume 'return'
        // Bare `return;` - always allowed, even in non-NoneType functions.
        if (this.acceptPunct(";")) return;
        // Scan the leading tokens for a literal/constructor before skipping.
        this.checkReturnType(retTok);
        this.skipExprUntil([";"]);
        this.expectPunct(";", "after return");
    }

    /** Inspect the leading tokens of a return expression and flag a
     * mismatch with the enclosing function's declared return type. */
    checkReturnType(retTok: Token) {
        // Top of stack is the innermost function's declared return type
        // (null = no declared type / NoneType; either way, no check).
        const declared = this.funcReturnStack[this.funcReturnStack.length - 1];
        if (declared === null || declared === undefined) return;

        const inferred = this.inferReturnType();
        if (inferred === null) return; // can't prove - leave alone
        if (inferred === declared) return;
        // Find the start of the expression (the first non-return token).
        const exprTok = this.peek();
        this.pushErr(exprTok,
            `Return type mismatch: function declared to return ` +
            `'${declared}' but expression looks like '${inferred}'.`);
    }

    /** Infer the Pylon type of the return expression starting at this.pos.
     * Returns null if we can't prove it from the leading literal alone.
     * Mirrors pylonc.py's `_infer_return_type`. */
    inferReturnType(): string | null {
        const toks = this.tokens;
        let i = this.pos;
        const n = toks.length;
        // Find the end of the return expression. We must track brace/paren/
        // bracket depth so that a `}` inside the expression (e.g. the `}`
        // of a `{}` dict literal, or the `}` closing a nested block in
        // `return {1: 2};`) doesn't prematurely end our scan. Only a `}` or
        // `;` at depth 0 ends the expression.
        let end = i;
        let depth = 0;
        while (end < n) {
            const t = toks[end];
            if (t.kind === "EOF") break;
            if (t.kind === "PUNCT") {
                if (depth === 0 && (t.value === ";" || t.value === "}")) break;
                if (t.value === "(" || t.value === "[" || t.value === "{") depth++;
                else if (t.value === ")" || t.value === "]" || t.value === "}") depth--;
            }
            end++;
        }
        if (end <= i) return null;
        const first = toks[i];
        const last = toks[end - 1];

        // --- single-token literals ---
        if (end - i === 1) {
            if (first.kind === "NUMBER") {
                const raw = first.value;
                if (raw.endsWith("j") || raw.endsWith("J")) return "complex";
                const lower = raw.toLowerCase();
                if (lower.startsWith("0x") || lower.startsWith("0o")
                    || lower.startsWith("0b")) {
                    return "int";
                }
                if (raw.includes(".") || raw.includes("e") || raw.includes("E")) {
                    return "float";
                }
                return "int";
            }
            if (first.kind === "STRING" || first.kind === "FSTRING") {
                // Look for a 'b'/'B' prefix before the opening quote.
                const qpos = first.value.search(/['"]/);
                if (qpos > 0) {
                    const prefix = first.value.slice(0, qpos).toLowerCase();
                    if (prefix.includes("b") && !prefix.includes("f")) {
                        return "bytes";
                    }
                }
                return "string";
            }
            if (first.kind === "NAME") {
                if (first.value === "True" || first.value === "False") {
                    return "boolean";
                }
                if (first.value === "None") return "NoneType";
            }
        }

        // --- constructor call: NAME ( ... ) ---
        if (first.kind === "NAME"
            && first.value in Parser.CONSTRUCTOR_TYPES
            && end - i >= 3
            && toks[i + 1].kind === "PUNCT" && toks[i + 1].value === "("
            && last.kind === "PUNCT" && last.value === ")") {
            return Parser.CONSTRUCTOR_TYPES[first.value];
        }

        // --- literal displays ---
        if (first.kind === "PUNCT" && first.value === "("
            && last.kind === "PUNCT" && last.value === ")") {
            // `()` or `(a, b, ...)` -> tuple; `(expr)` -> can't infer.
            if (end - i === 2) return "tuple"; // `()`
            let depth = 0;
            let sawComma = false;
            for (let j = i + 1; j < end - 1; j++) {
                const t = toks[j];
                if (t.kind === "PUNCT" && (t.value === "(" || t.value === "["
                    || t.value === "{")) depth++;
                else if (t.kind === "PUNCT" && (t.value === ")" || t.value === "]"
                    || t.value === "}")) depth--;
                else if (t.kind === "PUNCT" && t.value === "," && depth === 0) {
                    sawComma = true; break;
                }
            }
            if (sawComma) return "tuple";
            return null; // `(expr)` - can't infer
        }
        if (first.kind === "PUNCT" && first.value === "["
            && last.kind === "PUNCT" && last.value === "]") {
            return "list";
        }
        if (first.kind === "PUNCT" && first.value === "{"
            && last.kind === "PUNCT" && last.value === "}") {
            if (end - i === 2) return "dict"; // `{}`
            // `{...}` - dict if there's a `:` at depth 0, else set.
            let depth = 0;
            let sawColon = false;
            for (let j = i + 1; j < end - 1; j++) {
                const t = toks[j];
                if (t.kind === "PUNCT" && (t.value === "(" || t.value === "["
                    || t.value === "{")) depth++;
                else if (t.kind === "PUNCT" && (t.value === ")" || t.value === "]"
                    || t.value === "}")) depth--;
                else if (t.kind === "PUNCT" && t.value === ":" && depth === 0) {
                    sawColon = true; break;
                }
            }
            return sawColon ? "dict" : "set";
        }

        return null;
    }

    acceptOp(v: string): boolean {
        const t = this.peek();
        if (t.kind === "OP" && t.value === v) { this.pos++; return true; }
        if (t.kind === "PUNCT" && t.value === v) { this.pos++; return true; }
        return false;
    }

    parseFunc() {
        this.next(); // consume 'def'
        // Optional return type: a NAME that is a type, followed by a NAME that
        // is NOT a type (the function name).
        const cur = this.peek();
        const nxt = this.peek(1);
        let declaredRet: string | null = null;
        if (cur.kind === "NAME" && VALID_TYPE_NAMES.has(cur.value)
            && nxt.kind === "NAME" && !VALID_TYPE_NAMES.has(nxt.value)) {
            declaredRet = cur.value; // capture before consuming
            this.next(); // consume return type
        }
        const nameTok = this.expectName("after def");
        if (nameTok && KEYWORDS.has(nameTok.value)) {
            this.pushErr(nameTok,
                `Cannot use keyword '${nameTok.value}' as function name`);
        }
        if (!this.expectPunct("(", "after function name")) {
            // Try to recover by skipping to next '{'.
            this.skipExprUntil(["{"]);
        } else {
            // Parse parameters: list of (Type name | bare name) separated by ','.
            if (!this.acceptPunct(")")) {
                let depth = 1;
                while (depth > 0) {
                    const t = this.peek();
                    if (t.kind === "EOF") { return; }
                    if (t.kind === "PUNCT" && t.value === "(") depth++;
                    else if (t.kind === "PUNCT" && t.value === ")") { depth--; if (depth === 0) { this.pos++; break; } }
                    this.pos++;
                }
            }
        }
        // Function body is a new scope for const tracking. Push a fresh
        // set; module-level consts remain visible via isConst's outer-scope
        // lookup. Try/finally isn't needed because parseBlock always
        // returns (it pushes an "unclosed block" error at EOF), so the pop
        // is reached on every path including the early `return` above.
        this.constScopes.push(new Set());
        // NoneType is treated like "no declared type" - returns aren't
        // checked. We normalise here so the return-check only needs to
        // test for null.
        this.funcReturnStack.push(
            declaredRet === "NoneType" ? null : declaredRet);
        const savedRecovery = this.inRecovery;
        this.inRecovery = false; // function body is NOT recovery context
        this.parseBlock();
        this.inRecovery = savedRecovery;
        this.constScopes.pop();
        this.funcReturnStack.pop();
    }

    parseClass() {
        this.next(); // consume 'class'
        const nameTok = this.expectName("after class");
        if (nameTok && KEYWORDS.has(nameTok.value)) {
            this.pushErr(nameTok,
                `Cannot use keyword '${nameTok.value}' as class name`);
        }
        // Optional (Base, ...).
        if (this.acceptPunct("(")) {
            // Skip until matching ')'.
            let depth = 1;
            while (depth > 0) {
                const t = this.peek();
                if (t.kind === "EOF") return;
                if (t.kind === "PUNCT" && t.value === "(") depth++;
                else if (t.kind === "PUNCT" && t.value === ")") depth--;
                this.pos++;
            }
        }
        this.parseBlock();
    }

    parseIf() {
        this.next(); // consume 'if'
        this.skipExprUntil(["{"]);
        this.parseBlock();
        // elif / else chains.
        while (true) {
            const t = this.peek();
            if (t.kind === "NAME" && t.value === "elif") {
                this.next();
                this.skipExprUntil(["{"]);
                this.parseBlock();
            } else if (t.kind === "NAME" && t.value === "else") {
                this.next();
                this.parseBlock();
            } else break;
        }
    }

    parseWhileOrFor(kind: "while" | "for") {
        this.next(); // consume 'while' or 'for'
        this.skipExprUntil(["{"]);
        this.parseBlock();
    }

    parseTry() {
        this.next(); // consume 'try'
        // The try body itself is NOT recovery; only except/else/finally are.
        this.parseBlock();
        while (true) {
            const t = this.peek();
            if (t.kind === "NAME"
                && (t.value === "except" || t.value === "finally"
                    || t.value === "else")) {
                this.next();
                if (t.value === "except") {
                    // Optional: ExceptionType [as name]
                    if (!this.atWord("{")) {
                        this.skipExprUntil(["{"]);
                    }
                }
                // Mark the handler body as a recovery path so const
                // reassignment is permitted there.
                const saved = this.inRecovery;
                this.inRecovery = true;
                this.parseBlock();
                this.inRecovery = saved;
            } else break;
        }
    }

    parseWith() {
        this.next(); // consume 'with'
        // with EXPR as name { ... } - `as` is a keyword and would trip the
        // new-statement heuristic, so use permissive mode (skip to `{` only).
        this.skipExprUntil(["{"], true);
        this.parseBlock();
    }

    parseBlock() {
        if (!this.expectPunct("{", "to open block")) return;
        // Parse statements until '}'.
        while (!this.atEnd()) {
            const t = this.peek();
            if (t.kind === "PUNCT" && t.value === "}") { this.pos++; return; }
            const before = this.pos;
            this.parseStatement();
            // Safety: force-advance if a statement didn't consume anything.
            if (this.pos === before) this.pos++;
        }
        // Reached EOF without closing brace.
        this.pushErr(this.peek(), "Unclosed block: missing '}'");
    }
}

// --- public entry ---------------------------------------------------------

export function checkPylonSource(src: string): PylonDiagnostic[] {
    const doc: PylonDiagnostic[] = [];
    const tokens = tokenize(src, doc);
    const parser = new Parser(tokens, src, doc);
    parser.parseProgram();
    return doc;
}

// Re-export for tests.
export const __internals = {
    KEYWORDS, VALID_TYPE_NAMES, BUILTIN_FUNCS, tokenize, Parser,
};
