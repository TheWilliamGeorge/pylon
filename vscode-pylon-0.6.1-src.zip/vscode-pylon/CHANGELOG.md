# Changelog

All notable changes to the Pylon VS Code extension will be documented here.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.6.1] - 2026-11-18

### Fixed

- **Broken README logo.** The v0.6.0 package was built with
  `--baseImagesUrl`, which rewrote the relative logo path in the README
  into an absolute URL pointing at a non-existent GitHub repo, so the
  logo 404'd in the Extensions view. Rebuilt without that flag so image
  paths stay relative (VS Code resolves them against the installed
  extension folder).

### Changed

- The README hero now uses a centered, full-resolution Pylon logo
  (`icons/pylon-logo.png`, 1024×1024) displayed at 256px, instead of the
  small 256×256 extension icon. The full-res logo renders crisply in the
  Extensions view and on the marketplace.

## [0.6.0] - 2026-11-18

### Added

- **Comment and blank-line preservation in `pylon2py.py`.** The Python
  converter now keeps the author's `#` comments and blank-line spacing in
  the translated output, since it's a *converter*, not just a compiler.
  This includes:
  - Full-line comments above statements (preserved at the right indent).
  - Inline trailing comments on the same line as a statement
    (`int x = 5;  # important` → `x: int = 5  # important`), kept attached
    to their statement instead of being dropped or moved.
  - Blank lines between statements (vertical spacing survives).
  - Comments inside function/class/if/else bodies, at the correct
    indentation level.
  - Comments after the last statement in a block or at module scope.

  `#` inside string literals (single, double, or triple-quoted) is
  correctly NOT treated as a comment.

- **User-supplied Pylon logos.** The extension now ships with the real
  Pylon branding instead of placeholder icons:
  - `icons/extension-icon.png` — the main "Pylon Logo" (256×256 PNG),
    used as the extension's display icon in the Extensions view and the
    marketplace tile.
  - `icons/pylon-file.png` / `icons/pylon-file-dark.png` — the "Pylon
    Simple Logo No Glass" variant (32×32 PNG), used as the file icon
    next to `.pylon` files in the explorer. The simplified variant is
    used for the file icon because it stays legible at the small sizes
    VS Code renders file icons (16–32px), where the detailed main logo
    would lose detail. The same simple logo serves both light and dark
    themes.

  The old placeholder SVGs have been removed.

## [0.5.0] - 2026-11-18

### Added

- **Pylon → pure Python translator (`pylon2py.py`).** A new script, shipped
  alongside `pylonc.py`, that translates `.pylon` source into idiomatic
  pure Python with PEP 484 type hints — no Cython, no compilation. It
  reuses `pylonc.py`'s tokenizer, parser, AST, and the const-safety +
  return-type semantic checks verbatim, so the two translators never
  disagree on what's valid; only the emitter differs:

  | Pylon                         | Pure Python                |
  | ----------------------------- | -------------------------- |
  | `int x = 5;`                  | `x: int = 5`               |
  | `const int MAX = 100;`        | `MAX: int = 100`           |
  | `def int f(int n) { ... }`    | `def f(n: int) -> int:`    |
  | `def NoneType g() { ... }`   | `def g() -> None:`         |
  | `cdef` / `cpdef` / `bint` / `long` | dropped — plain Python |

  `const` is a Pylon-only concept (Python has no `const`), so the type
  hint is preserved and the const-safety check still runs at translation
  time — reassigning a const in the `.pylon` source fails the
  translation with the same error `pylonc` would give.

- **"Pylon: Translate to Python" command.** Right-click in any `.pylon`
  file → **Pylon: Translate to Python** (also in the Command Palette).
  Runs the bundled `pylon2py.py` and opens the translated Python in a
  new untitled editor for review — it does NOT compile or run anything,
  and it does NOT write a `.py` file next to your source (so it can't
  clobber an existing file). If translation fails, the error is shown in
  the Pylon output panel and as Problems-panel diagnostics on the
  offending lines.

  The command honors the same `pylon.pythonPath` / `pylon.pyloncPath`
  interpreter resolution as the compile commands.

## [0.4.0] - 2026-11-17

### Added

- **Compile-time and live return-type check.** Returning a value whose
  inferred type doesn't match the function's declared return type now
  raises a clear Pylon error — both at compile time in `pylonc.py` and as
  a live squiggly diagnostic in the editor — instead of the cryptic
  `TypeError: Expected str, got int` stack trace that Cython previously
  emitted at run time. Example:

  ```pylon
  def string f() {
      return 2;   // ERROR: return type mismatch: function declared to
  }              //        return 'string' but expression looks like 'int'.
  ```

- **Inference covers literals and constructor calls**: integer literals
  (`2`, `0x1F`), float literals (`2.5`, `1e10`), complex literals (`1j`),
  string and bytes literals (`"hi"`, `b"hi"`), `True`/`False`/`None`, the
  builtin constructors (`int(...)`, `str(...)`, `list(...)`, `dict(...)`,
  etc.), and the literal displays `[]`, `()`, `(a, b)`, `{}`, `{1: 2}`,
  `{1, 2}`.

- **Conservative by design.** Anything that can't be proven from the
  literal alone (variables, arithmetic, non-constructor function calls,
  parenthesised single expressions like `(1)`) is left alone — no false
  positives. A bare `return;` is **always allowed**, even in a function
  declared to return a non-`NoneType` type, since it's equivalent to
  `return None` (which Cython tolerates for object return types).

## [0.3.0] - 2026-11-16

### Added

- **Compile-time and live const-safety check.** Reassigning a `const`-declared
  name, augmented-assigning to it (`+=`, `-=`, …), or `del`-ing it now raises a
  clear error — both at compile time in `pylonc.py` and as a live squiggly
  diagnostic in the editor. The check respects scope (module-level consts are
  visible to nested functions via closure semantics; a local const in one
  function doesn't shadow a same-named local in another). Attribute and
  subscript assignments (`xs.append(4)` where `xs` is const) are intentionally
  NOT flagged — `const` binds the name, not the object it refers to.

- **Error-recovery exception.** Reassigning a const inside an `except`,
  `else`, or `finally` block of a `try` is ALLOWED, on the rationale that
  those blocks are the recovery path where re-binding a "constant" to a
  fallback value is the whole point of the handler (e.g.
  `const str cfg = load(); try { use(cfg) } except { cfg = DEFAULT; ... }`).
  Reassigning inside the `try` body itself is still an error.

- The TS checker now also parses the `else` clause of a `try` (previously it
  only handled `except` and `finally`).

## [0.2.0] - 2026-11-16

### Fixed

- **Compile-and-run failed under VS Code with "No such file or directory:
  'cython'"**. The root cause: VS Code's extension host launches subprocesses
  in a non-login shell with a stripped PATH, so pylonc's call to the bare
  `cython` CLI failed even though the `cython` Python package was installed.
  Fixed in `pylonc.py` by invoking `sys.executable -m cython` instead — the
  same interpreter that's running pylonc always finds cython, regardless of
  PATH.
- Same fix applied to the `.so` runner: `sys.executable -c "import ..."`
  replaces bare `python3`, so compiled programs run under the same
  interpreter that compiled them (avoids ABI mismatches).
- The C compiler is now resolved via a new `_resolve_compiler()` helper
  that respects the `CC` env var and falls back across `cc` → `gcc` →
  `clang`. If none is found, pylonc raises a clear `PylonError` with
  install instructions, instead of a cryptic `FileNotFoundError`.

### Added

- **`pylon.pythonPath` setting** — absolute path to the Python interpreter
  to use when invoking pylonc. Takes precedence over the Python extension's
  selected interpreter. When left empty, the extension auto-discovers the
  interpreter by checking the Python extension's active interpreter, then
  `python.defaultInterpreterPath`.
- The extension sanitizes PATH for the pylonc subprocess, appending common
  system bin dirs (`/usr/local/bin`, `/usr/bin`, `/opt/homebrew/bin`, the
  macOS Framework Python bin dir) so the C compiler and shell-init-only
  tools remain visible even under a stripped PATH.

## [0.1.0] - 2026-11-16

### Added

- Initial release.
- TextMate grammar covering Pylon types, keywords, function/class definitions,
  f-strings (with replacement fields and format specs), all string variants
  (f/r/b/u, single/double/triple-quoted), numbers (hex/oct/bin/float/complex),
  operators, comments, and built-in functions.
- Live diagnostics: a TypeScript port of pylonc.py's tokenizer and the
  error-detection parts of its parser. Reports missing semicolons, missing
  braces, keywords used as names, unknown types, missing parens, and
  unterminated strings as the user types (debounced).
- Snippets for `def`, `defn`, `defstr`, `class`, `for`, `forin`, `while`,
  `ifelse`, `ifelif`, `try`, `with`, typed variable declarations, `const`,
  `print`, `import`, `from`.
- Four commands: compile, compile --embed, compile & run, clean build
  artifacts. All wired to the configured `pylon.pyloncPath`, with output to a
  dedicated Pylon output channel and compiler errors mapped back into VS Code
  diagnostics.
- Custom file icon (light + dark theme SVG variants) for `.pylon` files in
  the Explorer.
- Sensible editor defaults for `.pylon` files (4-space indent, 100-col ruler,
  semantic highlighting on).
- Five configurable settings: `pyloncPath`, `enableDiagnostics`,
  `debounceMs`, `devMode`, `showOutputPanel`.
- Three sample `.pylon` files in `sample/` for testing.

### Known limitations

- The live checker is permissive about expression-level grammar; full type
  checking is delegated to `pylonc` at compile time.
- The file and marketplace icons are placeholders — replace the SVGs and PNG
  in `icons/` with your own before publishing.
